"""Check trajectory derivatives, bounds, timing and GUI commands without motors."""
import copy
import random
import unittest

from continuous_trajectory import ContinuousTrajectory
import test_sdk_gui_timed_playback as gui


def frame(start, target, duration=100, **options):
    return dict(name='walk', start_ms=start, time_ms=duration,
                angles={'0': target}, **options)


def velocity(plan, item, at, direction, step=0.01, joint=0):
    a = plan.sample_frame(item, at)[joint]
    b = plan.sample_frame(item, at + direction * step)[joint]
    return (b - a) / (direction * step)


class TrajectoryTests(unittest.TestCase):
    def test_adjacent_same_direction_has_shared_nonzero_velocity_and_acceleration(self):
        left, right = frame(0, 10), frame(100, 20)
        plan = ContinuousTrajectory([left, right], {0: 0})
        v_left = velocity(plan, left, 100, -1)
        v_right = velocity(plan, right, 100, 1)
        self.assertAlmostEqual(v_left, 0.1, places=6)
        self.assertAlmostEqual(v_left, v_right, places=6)
        h = 0.02
        a_left = (plan.sample_frame(left, 100)[0]
                  - 2 * plan.sample_frame(left, 100-h)[0]
                  + plan.sample_frame(left, 100-2*h)[0]) / h**2
        a_right = (plan.sample_frame(right, 100+2*h)[0]
                   - 2 * plan.sample_frame(right, 100+h)[0]
                   + plan.sample_frame(right, 100)[0]) / h**2
        self.assertAlmostEqual(a_left, 0.0, places=5)
        self.assertAlmostEqual(a_right, 0.0, places=5)

    def test_unequal_slopes_do_not_overshoot_saved_targets(self):
        rng = random.Random(42)
        for sign in (-1, 1):
            for _ in range(30):
                values = [sign * rng.uniform(0.01, 10)]
                values += [values[0] + sign * rng.uniform(0.01, 40)]
                durations = [rng.randint(10, 500), rng.randint(10, 500)]
                frames = [frame(0, values[0], durations[0]),
                          frame(durations[0], values[1], durations[1])]
                original = copy.deepcopy(frames)
                plan = ContinuousTrajectory(frames, {0: 0})
                previous = 0
                for item, target in zip(frames, values):
                    samples = [plan.sample_frame(item, item['start_ms'] +
                               i * item['time_ms'] / 100)[0] for i in range(101)]
                    self.assertEqual(samples[0], previous)
                    self.assertEqual(samples[-1], target)
                    for value in samples:
                        self.assertGreaterEqual(value, min(previous, target) - 1e-10)
                        self.assertLessEqual(value, max(previous, target) + 1e-10)
                    self.assertTrue(all(sign * (b-a) >= -1e-10
                                        for a, b in zip(samples, samples[1:])))
                    previous = target
                self.assertEqual(frames, original)

    def test_reversal_stationary_joint_landing_gap_and_cycle_stop(self):
        cases = [
            [frame(0, 10), frame(100, 0)],
            [frame(0, 10), frame(100, 10)],
            [frame(0, 10), dict(frame(100, 20), name='[착지]')],
            [dict(frame(0, 10), name='[착지]'), frame(100, 20)],
            [frame(0, 10), frame(150, 20)],
            [frame(0, 10, playback_cycle_end=True), frame(100, 20)],
            [frame(0, 10, stop_at_end=True), frame(100, 20)],
        ]
        for frames in cases:
            with self.subTest(frames=frames):
                plan = ContinuousTrajectory(frames, {0: 0})
                self.assertAlmostEqual(velocity(plan, frames[0], 100, -1), 0, places=6)
                self.assertAlmostEqual(velocity(plan, frames[1], frames[1]['start_ms'], 1),
                                       0, places=6)

    def test_sequence_start_and_end_are_at_rest(self):
        frames = [frame(0, 10), frame(100, 20)]
        plan = ContinuousTrajectory(frames, {0: 0})
        self.assertAlmostEqual(velocity(plan, frames[0], 0, 1), 0, places=6)
        self.assertAlmostEqual(velocity(plan, frames[1], 200, -1), 0, places=6)

    def test_sparse_joints_hold_instead_of_blending_over_an_omitted_frame(self):
        frames = [frame(0, 10), dict(frame(100, 20), angles={'1': 5}), frame(200, 20)]
        plan = ContinuousTrajectory(frames, {0: 0, 1: 0})
        self.assertAlmostEqual(velocity(plan, frames[0], 100, -1), 0, places=6)
        self.assertEqual(plan.sample_frame(frames[1], 150).keys(), {1})
        self.assertEqual(plan.sample_frame(frames[2], 200), {0: 10})
        self.assertAlmostEqual(velocity(plan, frames[2], 200, 1), 0, places=6)

    def test_shared_velocity_uses_composer_playback_time_at_different_speeds(self):
        left, right = frame(0, 10), frame(100, 20)
        plan = ContinuousTrajectory([left, right], {0: 0},
                                    lambda t: t if t <= 100 else 100 + 2*(t-100))
        h = 0.01  # playback milliseconds, not timeline milliseconds
        v_left = (10 - plan.sample_frame(left, 100-h)[0]) / h
        v_right = (plan.sample_frame(right, 100+h/2)[0] - 10) / h
        self.assertAlmostEqual(v_left, 0.05, places=6)
        self.assertAlmostEqual(v_left, v_right, places=6)


class GuiIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.player = gui.player()
        self.player.continuous_motion_enabled = True

    def test_actual_commands_cross_boundary_with_nonzero_speed_on_original_clock(self):
        p = self.player
        gui.set_frames(p, [frame(0, 10), frame(100, 20)])
        gui.tick(p, 0.095)
        before = p.calls[-1][1][0]
        gui.tick(p, 0.1)
        self.assertEqual(p.calls[-1], ('goal', {0: 10.0}))
        gui.tick(p, 0.105)
        after = p.calls[-1][1][0]
        self.assertGreater(10-before, 0.45)
        self.assertGreater(after-10, 0.45)
        self.assertEqual(p.current_timeline_ms, 105)
        self.assertEqual(p.anim_start_time, 0)
        gui.tick(p, 0.2)
        self.assertEqual(p.calls[-1], ('goal', {0: 20.0}))
        self.assertEqual(p.stops, [True])

    def test_lift_uses_full_frame_and_checkbox_off_restores_legacy_arrival(self):
        p = self.player
        item = dict(frame(0, 10), name='오들', lift_early_arrival=True)
        gui.set_frames(p, [item])
        gui.tick(p, 0.08)
        self.assertLess(p.calls[-1][1][0], 10)
        p.continuous_motion_enabled = False
        p.scrub_timeline(80, update_visuals=False)
        self.assertEqual(p.calls[-1], ('goal', {0: 10.0}))

    def test_gap_holds_final_target_without_changing_gap(self):
        p = self.player
        gui.set_frames(p, [frame(0, 10), frame(200, 20)])
        gui.tick(p, 0)
        gui.tick(p, 0.1)
        gui.tick(p, 0.15)
        self.assertEqual(p.calls[-1][1][0], 10)
        self.assertEqual(p.current_timeline_ms, 150)

    def test_feedback_delay_does_not_become_a_position_jump_or_wait(self):
        p = self.player
        gui.set_frames(p, [frame(0, 10), frame(100, 20)])
        p.feedback_angles = {0: -90}
        p.read_feedback_and_report_fk = lambda: False
        gui.tick(p, 0)
        gui.tick(p, 0.05)
        self.assertGreater(p.calls[-1][1][0], 0)
        self.assertLess(p.calls[-1][1][0], 10)
        self.assertTrue(p.is_playing)
        self.assertEqual(p.errors, [])

    def test_repeat_starts_from_previous_final_pose_on_original_schedule(self):
        p = self.player
        gui.set_frames(p, [frame(0, 10), frame(100, 20)])
        p.playback_repeat_target = 2
        gui.tick(p, 0)
        gui.tick(p, 0.1)
        gui.tick(p, 0.2)
        self.assertEqual(p.playback_repeat_current, 2)
        self.assertEqual(p.start_angles[0], 20)
        gui.tick(p, 0.205)
        self.assertGreater(p.calls[-1][1][0], 19.9)
        self.assertLess(p.calls[-1][1][0], 20)
        gui.tick(p, 0.3)
        gui.tick(p, 0.4)
        self.assertEqual(p.calls[-1], ('goal', {0: 20.0}))
        self.assertEqual(p.stops, [True])


if __name__ == '__main__':
    unittest.main()
