이 압축 파일 전체와 PROMPT_TO_ALGORITHM.md를 알고리즘 담당자에게 전달하세요.

이번 작업은 전달 자료 생성입니다. GUI 및 C++ 실행 코드는 수정하지 않았고 모터를 구동하지 않았습니다.

- sdk_gui.py: 현재 GUI 실행 소스, 동작 일치의 기준.
- sdk_gui_state.json: 전달 시점 저장 상태의 복사본(시퀀스 495개).
- robot_motions.json: 동봉 상태의 체크된 75개 모션을 GUI export 함수로 새로 생성한 실행 데이터.
- sdk_gui_timing_repairs.json: GUI의 기존 저장 조합 타이밍 복구 데이터.
- test_sdk_gui_*.py: GUI의 하드웨어 없는 검증에 사용하는 기존 테스트 3개 파일.
- cpp_sdk_current/: 현재 실제 C++ 모션 SDK 소스·빌드·테스트. GUI에 맞춰 수정 완료한 버전이 아닙니다. 실제 알고리즘 측 SDK와 비교할 참고 원본입니다.
- cpp_sdk_current/robot_motions.json: 루트의 새 실행 JSON과 동일한 복사본.
- export_changes.json: 기존 작업 폴더 배포 JSON과 새 export 사이 11개 모션의 차이.
- requirements-observed.txt: 조사 호스트에 설치된 Python 패키지 버전. 모든 대상 장치에서 검증된 고정 의존성 목록은 아닙니다.
- SOURCE_MANIFEST.json / SHA256SUMS: 스냅샷 출처·생성 방식·무결성.

외부 ROBOTIS C++ SDK 라이브러리/소스와 ROS 전체 프로젝트는 포함하지 않았습니다. C++ 빌드에는 Eigen3와 외부 Dynamixel SDK 등이 필요합니다. 기존 C++ 문서보다 PROMPT_TO_ALGORITHM.md의 최신 GUI 비교 지시를 우선하세요.

새 JSON 생성은 sdk_gui.py에서 실제 export 관련 메서드만 AST로 추출하여 저장 상태의 깊은 복사본에 실행했습니다. GUI 생성자와 하드웨어 통신은 실행하지 않았습니다. export의 레거시 겹침 보정으로 바뀐 모션 수: 0.

이번 포장 검증은 JSON 구조/배포 체크 항목 일치 및 ZIP 무결성 확인입니다. C++ 동작 일치, 이번 버전 테스트 실행, 실기 동작 검증을 완료했다는 뜻은 아닙니다. 기존 작업 폴더의 robot_motions.json과 sdk_gui_state.json은 덮어쓰지 않았습니다.
