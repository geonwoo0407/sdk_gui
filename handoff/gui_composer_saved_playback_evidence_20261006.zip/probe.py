import ast, contextlib, copy, hashlib, io, json, math, os, statistics, sys, time, types, uuid
from pathlib import Path
os.environ['QT_QPA_PLATFORM']='offscreen'
ROOT=Path(__file__).resolve().parent;OUT=ROOT / 'rerun';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT))
import test_sdk_gui_timed_playback as pb
from PyQt5 import QtCore,QtGui,QtWidgets
raw=(ROOT/'sdk_gui.py').read_bytes(); data=(ROOT/'sdk_gui_state.json').read_bytes();state=json.loads(data)
(OUT/'input_state.json').write_bytes(data)
source=ast.parse(raw)
ns=dict(pb.namespace, copy=copy,uuid=uuid)
for module in (QtCore,QtGui,QtWidgets):ns.update(vars(module))
methods={'composer_entry_frames','composer_entry_speed','composer_timing_segments','map_timeline_time',
'build_composed_sequence_frames','activate_composer_playback','save_composed_sequence','load_saved_sequence',
'play_motion_page_sequence','stop_motion_sequence','resort_motion_sequence','timeline_state_at','motion_end_ms'}
cls=next(n for n in source.body if isinstance(n,ast.ClassDef) and n.name=='SDKMotionEditor')
helper=ast.ClassDef(name='Helper',bases=[],keywords=[],decorator_list=[],body=[n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in methods])
ns['QInputDialog']=types.SimpleNamespace(getText=lambda *a:('probe',True))
ns['QMessageBox']=types.SimpleNamespace(warning=lambda *a:None,information=lambda *a:None)
widgets=[n for n in source.body if isinstance(n,ast.ClassDef) and n.name=='JointTrajectoryWidget']
exec(compile(ast.fix_missing_locations(ast.Module(body=[helper]+widgets,type_ignores=[])),str(ROOT/'sdk_gui.py'),'exec'),ns)
Helper=ns['Helper']
saved=state['saved_sequences'][-1]
base_idx=next(i for i,s in enumerate(state['saved_sequences']) if s['sequence_id']=='9215fc1cb5b8442aa64b4179799e8062')
c=Helper();c.saved_sequences=copy.deepcopy(state['saved_sequences']);c.sequence_composer_entries=[dict(sequence_idx=base_idx,repeat_count=4,gap_before_ms=g,time_ms=2080+g) for g in (0,200)]
frames,duration=c.build_composed_sequence_frames();baked,baked_duration=c.build_composed_sequence_frames(True)
assert frames==baked==saved['frames']
noop=lambda *a,**kw:None
class Spin:
 def __init__(self,v):self.v=v
 def value(self):return self.v
 def setValue(self,v):self.v=v
c.spin_composer_repeat=Spin(1);c.spin_composer_speed=Spin(1.0);c.refresh_sequence_list=noop;c.save_persistent_state=noop
c.save_composed_sequence();assert c.saved_sequences[-1]['frames']==saved['frames']
c.spin_max_time=Spin(5000);c.spin_motion_repeat=Spin(1);c.spin_motion_speed=Spin(1.0)
c.refresh_timeline_ui=c.resort_motion_sequence;c.auto_fit_timeline_to_frame_times=noop
c.lbl_loaded_sequence=types.SimpleNamespace(setText=noop);c.update_sequence_save_button=noop
c.tabs=types.SimpleNamespace(setCurrentWidget=noop);c.tab_motion=object();c.playback_context='motion';c.is_paused=False;c.playback_paused_by_button=False
c.load_saved_sequence(len(c.saved_sequences)-1);assert c.motion_sequence==saved['frames']
played=[];c.play_keyframe_sequence=lambda:played.append(copy.deepcopy(c.motion_sequence));c.play_motion_page_sequence();assert played[-1]==saved['frames']
initial={int(k):v for k,v in frames[-1]['angles'].items()}
def make_player(context):
 p=pb.player();pb.set_frames(p,copy.deepcopy(frames));p.start_angles=initial.copy();p.joints=initial.copy();p.online_joints=set(initial);p.feedback_angles=initial.copy()
 p.playback_context=context;p.playback_speed=1.0;p.is_paused=False
 if context=='composer':
  p.composer_playback_segments=c.composer_timing_segments();p.COMPOSER_SCALE=1.0;p.composer_timeline_container=p.timeline_container;p.composer_timeline_scroll=p.timeline_scroll
 return p
# Deterministic command equality, with identical timing and initial posture.
a,b=make_player('composer'),make_player('motion')
with contextlib.redirect_stdout(io.StringIO()):
 for i in range(1200):
  for p in (a,b):
   if p.is_playing:pb.tick(p,i*.005)
  if not(a.is_playing or b.is_playing):break
assert a.calls==b.calls
summary={'source_sha256':hashlib.sha256(raw).hexdigest(),'state_sha256':hashlib.sha256(data).hexdigest(),
'sequence_name':saved['name'],'source_name':state['saved_sequences'][base_idx]['name'],'reconstructed_entries':[{'repeat':4,'gap_ms':g} for g in (0,200)],
'frame_count':len(frames),'duration_ms':duration,'cycle_flags':sum(bool(f.get('playback_cycle_end')) for f in frames),
'frames_equal_raw_baked_saved_reloaded':True,'deterministic_goal_writes_equal':True,'goal_count':len(a.calls),'ui_runs':[]}
app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
class Graph(ns['JointTrajectoryWidget']):
 def __init__(self,p):super().__init__(p);self.paint_costs=[]
 def paintEvent(self,event):
  started=time.perf_counter();super().paintEvent(event);self.paint_costs.append((time.perf_counter()-started)*1000)
def percentiles(values):
 if not values:return {'count':0}
 values=sorted(values)
 return {'count':len(values),'median_ms':statistics.median(values),'p95_ms':values[min(len(values)-1,int(.95*len(values)))],'max_ms':max(values)}
for run_no in range(2):
 for mode in ('composer_hidden_graph','motion_visible_graph','motion_cached_graph'):
  p=make_player('composer' if mode.startswith('composer') else 'motion')
  p.timeline_state_at=types.MethodType(Helper.timeline_state_at,p);p.motion_end_ms=types.MethodType(Helper.motion_end_ms,p)
  p.torque_btns={j:types.SimpleNamespace(isChecked=lambda:True) for j in initial}
  p.combo_trajectory_group=types.SimpleNamespace(currentData=lambda:22,currentText=lambda:'22: ankle_roll')
  p.joint_data=[dict(id=j,name=str(j)) for j in initial]
  graph=Graph(p);graph.resize(1200,320);p.trajectory_graph=graph
  sample_costs=[]
  for i in range(10):
   start=time.perf_counter();graph.trajectory_samples([22]);sample_costs.append((time.perf_counter()-start)*1000)
  if mode=='motion_cached_graph':
   cached=graph.trajectory_samples([22]);graph.trajectory_samples=lambda ids:cached
  if mode!='composer_hidden_graph':graph.show()
  app.processEvents();graph.paint_costs.clear()
  events=[];ticks=[];loop=QtCore.QEventLoop();timer=QtCore.QTimer();timer.setTimerType(QtCore.Qt.PreciseTimer);timer.setInterval(5)
  pb.namespace['time']=types.SimpleNamespace(perf_counter=time.perf_counter)
  origin=time.perf_counter();p.anim_start_time=origin
  def tx(angles,**kw):
   events.append(dict(wall_ms=(time.perf_counter()-origin)*1000,timeline_ms=p.current_timeline_ms,angles=angles.copy()));return True
  def step():
   ticks.append((time.perf_counter()-origin)*1000);p.anim_step()
   if not p.is_playing:timer.stop();loop.quit()
  p.write_goal_positions=tx;timer.timeout.connect(step)
  with contextlib.redirect_stdout(io.StringIO()):timer.start();loop.exec_()
  intervals=[b['wall_ms']-a['wall_ms'] for a,b in zip(events,events[1:])]
  tick_intervals=[b-a for a,b in zip(ticks,ticks[1:])]
  row={'mode':mode,'run':run_no+1,'wall_duration_ms':events[-1]['wall_ms'],
       'writes':len(events),'write_intervals':percentiles(intervals),'write_gaps_over_10ms':sum(v>10 for v in intervals),
       'tick_intervals':percentiles(tick_intervals),'paint':percentiles(graph.paint_costs),'trajectory_calculation':percentiles(sample_costs)}
  summary['ui_runs'].append(row);print(json.dumps(row),flush=True)
  (OUT/f'{mode}_{run_no+1}_trace.json').write_text(json.dumps(events))
  graph.close();graph.deleteLater();app.processEvents()
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print('RESULT',json.dumps({k:v for k,v in summary.items() if k!='ui_runs'},ensure_ascii=False))
