import ast,contextlib,copy,hashlib,io,json,math,os,statistics,sys,time,types,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'rerun';OUT.mkdir(exist_ok=True);sys.path.insert(0,str(ROOT))
import test_sdk_gui_timed_playback as pb
import dynamixel_sdk as dxl
from dynamixel_sdk.port_handler import PortHandler,LATENCY_TIMER
from dynamixel_sdk.group_sync_read import GroupSyncRead
from dynamixel_sdk.group_sync_write import GroupSyncWrite
raw=(ROOT/'sdk_gui.py').read_bytes();tree=ast.parse(raw);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='SDKMotionEditor')
ns=dict(pb.namespace,copy=copy,os=os,ET=ET,time=time);ns.update(vars(dxl))
wanted={'calculate_fk_tracking_error','angles_to_urdf_radians','normalize_angles','shortest_angle_delta','read_feedback_and_report_fk','print_fk_tracking_error','angle_to_dxl_position','dxl_position_to_angle','write_goal_positions','set_tracking_target_angles','start_motion_playback','step_frame_apply'}
helpers=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('_parse_vec3','_transform_from_xyz_rpy','_axis_angle_transform')]
helpers += [n for n in tree.body if isinstance(n,ast.ClassDef) and n.name in ('SimpleURDFModel','SafeProtocol2PacketHandler')]
helpers += [ast.ClassDef(name='Helper',bases=[],keywords=[],decorator_list=[],body=[n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in wanted])]
exec(compile(ast.fix_missing_locations(ast.Module(body=helpers,type_ignores=[])),str(ROOT/'sdk_gui.py'),'exec'),ns)
H=ns['Helper'];ph=ns['SafeProtocol2PacketHandler']();h=H();h.packetHandler=ph
for a in ast.walk(next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')):
 if isinstance(a,ast.Assign) and any(isinstance(t,ast.Attribute) and t.attr=='urdf_joint_map' for t in a.targets):h.urdf_joint_map=ast.literal_eval(a.value)
motion=json.loads((ROOT/'input_motion.json').read_text())
angles={int(k):v for k,v in motion['frames'][-1]['angles'].items()};h.online_joints=sorted(angles)
h.feedback_angles={j:v-2 for j,v in angles.items()};h.commanded_angles=angles.copy();h.commanded_joint_ids=set(angles)
h.robot_model=ns['SimpleURDFModel'].load(str(ROOT/'step.urdf'),load_visuals=False);h.urdf_loaded=True
h.fk_feedback_read_failures=0;h.fk_feedback_sample_count=0;h.last_fk_read_error_log_time=0.;h.last_fk_error_log_time=0.
def stats(v):
 v=sorted(v);return dict(count=len(v),median_ms=statistics.median(v),p95_ms=v[int(.95*(len(v)-1))],max_ms=max(v))
def bench(fn,n=250):
 for i in range(10):fn()
 times=[]
 for i in range(n):
  st=time.perf_counter();fn();times.append((time.perf_counter()-st)*1000)
 return stats(times)
summary={'source_sha256':hashlib.sha256(raw).hexdigest(),'motion':motion['name'],'limitations':'No serial port opened. FK uses current code and step.urdf. Packet I/O is synthetic, including deliberately injected delays. CPU timings apply to this PC only.'}
summary['fk_with_urdf']=bench(h.calculate_fk_tracking_error)
h.urdf_loaded=False;summary['joint_error_without_urdf']=bench(h.calculate_fk_tracking_error);h.urdf_loaded=True
class FakePort(PortHandler):
 def __init__(self):
  super().__init__('NO_HARDWARE');self.tx_time_per_byte=.0025;self.delay_ms=0.;self.respond=True;self.buffer=bytearray();self.polls=0;self.writes=[]
 def clearPort(self):self.buffer.clear()
 def writePort(self,pkt):
  self.writes.append(bytes(pkt))
  if pkt[7]==0x82 and self.respond:
   for j in pkt[12:-2]:
    pos=h.angle_to_dxl_position(h.feedback_angles.get(j,0.));data=[pos & 255,(pos>>8)&255,(pos>>16)&255,(pos>>24)&255]
    reply=[255,255,253,0,j,8,0,0x55,0]+data+[0,0];crc=ph.updateCRC(0,reply,len(reply)-2);reply[-2:]=[crc&255,crc>>8];self.buffer.extend(reply)
   self.ready_at=time.perf_counter()+self.delay_ms/1000
  return len(pkt)
 def readPort(self,length):
  self.polls+=1
  if not self.respond or time.perf_counter()<self.ready_at:return b''
  part=self.buffer[:length];del self.buffer[:length];return bytes(part)
port=FakePort();h.groupSyncRead=GroupSyncRead(port,ph,ns['ADDR_PRESENT_POSITION'],4);h.groupSyncWrite=GroupSyncWrite(port,ph,ns['ADDR_GOAL_POSITION'],4);h.port_opened=True
h.print_fk_tracking_error=lambda *a:None
summary['read_all_immediate_fake_packets_with_fk']=bench(h.read_feedback_and_report_fk,150)
summary['write_goals_fake_port']=bench(lambda:h.write_goal_positions(angles,read_feedback=False),250)
summary['sdk_fake_reply_delay_cases']=[]
for delay,reply in ((0,True),(5,True),(16,True),(0,False)):
 port.delay_ms=delay;port.respond=reply;port.polls=0;t=time.perf_counter()
 with contextlib.redirect_stdout(io.StringIO()):ok=h.read_feedback_and_report_fk()
 summary['sdk_fake_reply_delay_cases'].append(dict(injected_response_delay_ms=delay,respond=reply,result=ok,elapsed_ms=(time.perf_counter()-t)*1000,read_poll_calls=port.polls,configured_timeout_ms=(.0025*(11+4)*len(h.online_joints)+LATENCY_TIMER*2+2)))
summary['linux_usb_latency_timer']={str(p):p.read_text().strip() for p in Path('/sys/bus/usb-serial/devices').glob('*/latency_timer')}
# Deterministic callback shows the repetition clock excludes boundary feedback duration.
p=pb.player();pb.set_frames(p,[pb.frame(start=0,duration=100)]);p.playback_repeat_target=2
clock=[1.0];p.anim_start_time=clock[0];ev=[]
pb.namespace['time']=types.SimpleNamespace(perf_counter=lambda:clock[0])
def tx(a,**kw):ev.append(dict(event='write',wall_ms=round((clock[0]-1)*1000,6),angles=a.copy()));return True
def rx():ev.append(dict(event='read_begin',wall_ms=round((clock[0]-1)*1000,6)));clock[0]+=.016;ev.append(dict(event='read_end',wall_ms=round((clock[0]-1)*1000,6)));return True
p.write_goal_positions=tx;p.read_feedback_and_report_fk=rx
with contextlib.redirect_stdout(io.StringIO()):
 p.scrub_timeline(95,update_visuals=False)
 ev=[];clock[0]=1.1;p.anim_step()
summary['boundary_with_16ms_feedback']={'events':ev,'restart_wall_ms':round((p.anim_start_time-1)*1000,6),'logical_timeline_ms':p.current_timeline_ms,'repeat':p.playback_repeat_current}
# Feedback can immediately become due again when the read itself takes >=10ms.
p=pb.player();pb.set_frames(p,[pb.frame(duration=500)]);clock=[1.];p.anim_start_time=1.;events=[]
pb.namespace['time']=types.SimpleNamespace(perf_counter=lambda:clock[0]);p.write_goal_positions=lambda a,**kw:events.append(('write',round((clock[0]-1)*1000,6))) or True
p.read_feedback_and_report_fk=lambda:events.append(('read',round((clock[0]-1)*1000,6))) or clock.__setitem__(0,clock[0]+.016) or True
with contextlib.redirect_stdout(io.StringIO()):
 for i in range(4):p.anim_step();clock[0]+=.005
summary['16ms_read_plus_5ms_scheduler_events']=events
# Normal playback startup does not cancel an already active single-frame timer.
p=pb.player();pb.set_frames(p,copy.deepcopy(motion['frames']));p.playback_paused_by_button=False;p.start_angles=angles.copy();p.joints=angles.copy();p.is_paused=False
class Timer:
 def __init__(self,active=False):self.active=active
 def stop(self):self.active=False
 def start(self):self.active=True
 def isActive(self):return self.active
p.frame_apply_timer=Timer(True);p.anim_timer=Timer();p.robot_scrub_timer=Timer();p.resort_motion_sequence=lambda:None;p.sync_sequence_start_from_robot=lambda:True
with contextlib.redirect_stdout(io.StringIO()):H.start_motion_playback(p,real_robot=True,start_ms=0)
summary['single_frame_timer_after_sequence_start']=p.frame_apply_timer.isActive()
# Current active sleep call sites and whether the legacy profile command is called.
calls=[]
for method in cls.body:
 if isinstance(method,ast.FunctionDef):
  for node in ast.walk(method):
   if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr in ('sleep','command_time_profile_frame','save_persistent_state'):
    calls.append(dict(caller=method.name,call=node.func.attr,line=node.lineno))
summary['call_sites']=calls
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='call_sites'},ensure_ascii=False,indent=2))
