import ast
import contextlib
import copy
import hashlib
import io
import json
import math
import sys
import types
import zipfile
from pathlib import Path

ROOT = Path('/home/rnd_3/final step')
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
import test_sdk_gui_timed_playback as pb

source = ast.parse((ROOT / 'sdk_gui.py').read_text())
gui = next(n for n in source.body if isinstance(n, ast.ClassDef) and n.name == 'SDKMotionEditor')
composer_names = {'composer_entry_frames', 'composer_entry_speed', 'composer_timing_segments',
                  'map_timeline_time', 'build_composed_sequence_frames'}
extra_names = {'sync_sequence_start_from_robot', 'start_motion_playback'}
ns = dict(pb.namespace, copy=copy)
for name, wanted in [('Composer', composer_names), ('Extra', extra_names)]:
    cls = ast.ClassDef(name=name, bases=[], keywords=[], decorator_list=[],
                      body=[n for n in gui.body if isinstance(n, ast.FunctionDef) and n.name in wanted])
    exec(compile(ast.fix_missing_locations(ast.Module(body=[cls], type_ignores=[])),
                 str(ROOT / 'sdk_gui.py'), 'exec'), ns)

with zipfile.ZipFile(ROOT / 'handoff/gui_reference_for_algorithm_20261006.zip') as z:
    catalog = json.loads(z.read('robot_motions.json'))['motions']
    package_hash = hashlib.sha256(z.read('robot_motions.json')).hexdigest()

def compose(motion, blocks=4):
    c = ns['Composer']()
    c.saved_sequences = [motion]
    duration = max(f['start_ms'] + f['time_ms'] for f in motion['frames'])
    c.sequence_composer_entries = [dict(kind='sequence', sequence_idx=0, repeat_count=4,
                                       gap_before_ms=0, time_ms=duration * 4) for _ in range(blocks)]
    frames, total = c.build_composed_sequence_frames()
    return frames, c.composer_timing_segments(), total

def run(frames, repeats, speed, initial, delay_read_ms, delay_write_ms,
        segments=None, tick_ms=5, constant_actual=None, save_name=None):
    p = pb.player()
    pb.set_frames(p, copy.deepcopy(frames))
    p.online_joints = set(initial)
    p.start_angles = initial.copy()
    p.joints = initial.copy()
    p.feedback_angles = (constant_actual or initial).copy()
    p.playback_repeat_target = repeats
    p.playback_speed = speed
    if segments is not None:
        p.playback_context = 'composer'
        p.composer_playback_segments = segments
        p.COMPOSER_SCALE = 1.0
        p.composer_timeline_container = p.timeline_container
        p.composer_timeline_scroll = p.timeline_scroll
    clock = [1.0]  # positive monotonic origin, as in a real running process
    p.anim_start_time = clock[0]
    origin = clock[0]
    events = []
    phase = ['tick']
    def stamp(): return round((clock[0] - origin) * 1000, 6)
    def tx(angles, **kwargs):
        e = dict(event='tx', phase=phase[0], begin_ms=stamp(), timeline_ms=p.current_timeline_ms,
                 repeat=p.playback_repeat_current, angles={str(k):v for k,v in angles.items()})
        clock[0] += delay_write_ms / 1000
        e['end_ms'] = stamp()
        events.append(e)
        return True
    def rx():
        e = dict(event='rx', phase=phase[0], begin_ms=stamp(), timeline_ms=p.current_timeline_ms)
        clock[0] += delay_read_ms / 1000
        if constant_actual is not None: p.feedback_angles.update(constant_actual)
        e['end_ms'] = stamp()
        e['actual_angles'] = {str(k):v for k,v in p.feedback_angles.items()}
        events.append(e)
        return True
    gate = p.gate_timeline_on_frame_arrival
    def gated(*args, **kwargs):
        previous = phase[0]; phase[0] = 'frame_endpoint'
        try: return gate(*args, **kwargs)
        finally: phase[0] = previous
    scrub = p.scrub_timeline
    def scrubbed(*args, **kwargs):
        previous = phase[0]; phase[0] = 'scrub'
        try: return scrub(*args, **kwargs)
        finally: phase[0] = previous
    restart = p.restart_playback_cycle
    def restarted(timeline, last_frame):
        restart(timeline, last_frame)
        events.append(dict(event='restart', at_ms=stamp(), timeline_ms=timeline,
                           start_angles={str(k):v for k,v in p.start_angles.items()},
                           feedback_angles={str(k):v for k,v in p.feedback_angles.items()}))
    p.write_goal_positions = tx
    p.read_feedback_and_report_fk = rx
    p.gate_timeline_on_frame_arrival = gated
    p.scrub_timeline = scrubbed
    p.restart_playback_cycle = restarted
    original_clock = pb.namespace['time']
    pb.namespace['time'] = types.SimpleNamespace(perf_counter=lambda:clock[0])
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            while p.is_playing and clock[0] - origin < 120:
                p.anim_step()
                clock[0] += tick_ms / 1000
    finally: pb.namespace['time'] = original_clock
    assert not p.is_playing
    if save_name: (OUT / save_name).write_text(json.dumps(events, ensure_ascii=False, indent=2))
    return events, stamp()

def comparable(events):
    return [(e['event'], e.get('begin_ms', e.get('at_ms')), e.get('end_ms'),
             e.get('angles'), e.get('actual_angles')) for e in events]

summary = {'source_sha256': hashlib.sha256((ROOT/'sdk_gui.py').read_bytes()).hexdigest(),
           'motion_source':'handoff/gui_reference_for_algorithm_20261006.zip:robot_motions.json',
           'motion_source_sha256':package_hash, 'cases':[],
           'limitations':'Methods extracted from current GUI source; simulated I/O and scheduler; no motor port opened; no physical dynamics or UI rendering cost modeled.'}
for motion_name in ['건전진45도(4회)', '건전진90도(4회)']:
    m = next(x for x in catalog if x['name']==motion_name)
    initial = {int(k):v-3.0 for k,v in m['frames'][-1]['angles'].items()}
    for source_speed in [1.0, 0.9]:
        m = dict(m, playback_speed=source_speed)
        combined, segments, total = compose(m)
        for rd in [0,5,15,40]:
            for wd in [0,1]:
                save = motion_name=='건전진45도(4회)' and source_speed==1 and rd==15 and wd==1
                a,ta=run(m['frames'],16,source_speed,initial,rd,wd,
                         save_name='A_16cycles_simulated.json' if save else None)
                b,tb=run(combined,1,1.0,initial,rd,wd,segments=segments,
                         save_name='B_4blocks_x4_simulated.json' if save else None)
                ca,cb=comparable(a),comparable(b)
                equal=ca==cb
                first_diff=next((i for i,(x,y) in enumerate(zip(ca,cb)) if x!=y),None)
                max_angle_delta=0
                for x,y in zip(a,b):
                    if x['event']==y['event']=='tx' and x['angles'].keys()==y['angles'].keys():
                        max_angle_delta=max(max_angle_delta,max(abs(v-y['angles'][k]) for k,v in x['angles'].items()))
                case=dict(motion=motion_name,source_speed=source_speed,read_ms=rd,write_ms=wd,
                          events_A=len(a),events_B=len(b),tx_A=sum(e['event']=='tx' for e in a),
                          tx_B=sum(e['event']=='tx' for e in b),restarts_A=sum(e['event']=='restart' for e in a),
                          restarts_B=sum(e['event']=='restart' for e in b),elapsed_A_ms=ta,elapsed_B_ms=tb,
                          exactly_equal=equal,first_differing_event=first_diff,max_goal_delta=max_angle_delta)
                if not equal and first_diff is not None:
                    case['difference_excerpt']=[a[first_diff],b[first_diff]]
                summary['cases'].append(case)

# Specific 60-degree command vs 57-degree measurement example.
synthetic=[pb.frame('오들',start=90,duration=80,angles={'0':30.0}),
           pb.frame('오뒤',start=170,duration=110,angles={'0':60.0})]
events,_=run(synthetic,2,1.0,{0:57.0},15,1,constant_actual={0:57.0},save_name='60_vs_57_repeat_example.json')
restart_i=next(i for i,e in enumerate(events) if e['event']=='restart')
summary['60_vs_57']={'boundary_excerpt':events[max(0,restart_i-3):restart_i+8]}

# Fresh start calls the actual start and read-initial-angle GUI methods, with mocked hardware.
p=pb.player(); pb.set_frames(p,synthetic)
for n in extra_names: setattr(p,n,types.MethodType(getattr(ns['Extra'],n),p))
p.playback_paused_by_button=False; p.is_paused=False
p.start_angles={0:60.0}; p.joints={0:60.0}; p.online_joints={0}
p.commanded_angles={}; p.commanded_joint_ids=set()
p.robot_scrub_timer=types.SimpleNamespace(stop=lambda:None)
p.anim_timer=types.SimpleNamespace(start=lambda:None,stop=lambda:None)
p.sequence_joint_ids=lambda:{0}
p.read_present_angle=lambda jid:57.0
p.update_joint_display=lambda jid,angle,**kw:p.joints.update({jid:angle})
p.update_3d_robot=lambda *args:None
p.resort_motion_sequence=lambda:None
ns['time']=types.SimpleNamespace(perf_counter=lambda:100.0)
with contextlib.redirect_stdout(io.StringIO()): p.start_motion_playback(real_robot=True,start_ms=0)
summary['fresh_start_C']={'start_angles':p.start_angles,'feedback_angles':p.feedback_angles,'anim_start_time':p.anim_start_time}
p.calls=[]
p.scrub_timeline(0,update_visuals=False)
summary['fresh_start_C']['first_goal']=p.calls[-1]

(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print('Cases:',len(summary['cases']),'exactly equal:',sum(c['exactly_equal'] for c in summary['cases']))
for c in summary['cases']:
    if not c['exactly_equal']:print(json.dumps(c,ensure_ascii=False))
print('Example boundary:',json.dumps(summary['60_vs_57'],ensure_ascii=False))
print('Fresh start C:',json.dumps(summary['fresh_start_C'],ensure_ascii=False))
print('Results:',OUT)
