2026-10-06 read-only audit.
GUI/SDK application source and motion data were not modified.
All trace JSON files are SIMULATED, not physical measurements.
probe.py extracts methods from the current workspace GUI through test_sdk_gui_timed_playback and mocks all hardware access; it does not construct the application or open a port.
Scheduler assumption: complete each tick, then advance another 5 ms; UI and physical dynamics are not modeled.
queue_poll_probe.cpp uses the historical local reference SdkExecutorCore with FakeMotionBackend, not the deployed Jetson binary.
Existing tests: QT_QPA_PLATFORM=offscreen python3 -m unittest test_sdk_gui_timed_playback test_sdk_gui_composer_timeline test_sdk_gui_precision — 40 tests passed.
Reproduction requires the original workspace files with the hashes recorded in source_hashes.json and the named handoff ZIP.
