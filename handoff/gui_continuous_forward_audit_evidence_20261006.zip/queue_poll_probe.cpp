#include "fake_motion_backend.hpp"
#include "irc_step_motion_executor/sdk_executor_core.hpp"
#include <cassert>
#include <iostream>
#include <string>

std::string request(int id) {
  return "{\"action\":\"STRAIGHT\",\"command_id\":1,\"event_id\":null,"
         "\"request_id\":" + std::to_string(id) +
         ",\"motion_id\":\"forward\",\"timeout_ms\":5000}";
}
int main(int argc, char** argv) {
  assert(argc==2);
  irc_step_motion_executor::MotionAliasCatalog catalog;
  std::string error;
  assert(catalog.load(argv[1], error));
  FakeMotionBackend backend;
  backend.queue_result={true,"","queued"};
  irc_step_motion_executor::SdkExecutorCore core(catalog,backend);
  assert(core.handle_request(request(1),0).status=="RUNNING");
  assert(core.handle_request(request(2),5).status=="QUEUED");
  backend.sequence=1; // Simulate completion/activation already observable by next poll.
  std::cout << "poll_ms,backend_poll_calls,status,message\n";
  for (const auto now : {100,105,110}) {
    const auto status=core.poll(now);
    assert(status);
    std::cout<<now<<','<<backend.poll_calls<<','<<status->status<<','<<status->message<<'\n';
    if(now==105) assert(backend.poll_calls==1);
  }
  assert(backend.poll_calls==2);
}
